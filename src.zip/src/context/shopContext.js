import { createContext } from "react";
import { useCart } from "../hook/useCart";

const SHopContext = createContext({
    cartItems: null,
    addToCart: ()=>{},
    removeFromCart : ()=>{}
});
export const ShopContextProvider = (props)=>{
    return <ShopContextProvider value={useCart()}>{props.children}</ShopContextProvider>
}