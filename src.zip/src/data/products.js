import mobile from '../assets/mobile.jpg';
import bag from '../assets/b.webp';
import bikiny from '../assets/bikiny.webp';
import wine from '../assets/wine.jpg';
export const PRODUCTS = [
    {
        id : 1 ,
        productName : "Mobile",
        price : 1000,
        productImage : mobile
    },
    {
        id : 2 ,
        productName : "Bag",
        price : 750,
        productImage : bag
    },
    {
        id : 3 ,
        productName : "Bikiny",
        price : 1750,
        productImage : bikiny
    },
    {
        id : 4 ,
        productName : "Wine",
        price : 250,
        productImage : wine
    },
]